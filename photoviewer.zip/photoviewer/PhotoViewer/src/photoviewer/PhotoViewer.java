package photoviewer;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.UUID;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnectionNotifier;

public class PhotoViewer extends Application {

    private static final int KEYBOARD_CONTROL = 0;
    private static final int PHONE_CONTROL = 1;

    private Stage window;
    private Scene scene;
    private TextField directoryPath;
    private StreamConnectionNotifier notifier;

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.window = primaryStage;
        this.window.setTitle("Photo Viewer");

        VBox layout = new VBox(17);
        layout.setPadding(new Insets(15));

        // Directory path text field
        directoryPath = new TextField();
        directoryPath.setPromptText("Directory path");
        directoryPath.setMinWidth(280);
        directoryPath.setMinHeight(35);

        // Browse button
        Button browseButton = new Button();
        browseButton.setText("Browse...");
        browseButton.setMinHeight(35);
        browseButton.setMinWidth(100);
        browseButton.setOnAction(e -> {
            DirectoryChooser directoryChooser = new DirectoryChooser();
            File selectedDirectory = directoryChooser.showDialog(window);
            if (selectedDirectory != null) {
                directoryPath.setText(selectedDirectory.getAbsolutePath());
            }
        });

        // mode selection 
        ComboBox<String> controlWith = new ComboBox<>();
        controlWith.getItems().addAll("Keypad", "Phone");
        controlWith.setPromptText("Control with...");
        controlWith.setMinHeight(35);
        controlWith.setMinWidth(200);
        controlWith.setOnAction(e -> {
            System.out.println("Selected controller: " + controlWith.getValue());
        });

        // view button 
        Button viewButton = new Button();
        viewButton.setText("View");
        viewButton.setMinHeight(35);
        viewButton.setMinWidth(150);
        viewButton.setOnAction(e -> {
            File dir = new File(this.directoryPath.getText());
            if (dir.isDirectory()) {
                System.out.println("Start photo viewer...");
                if (controlWith.getValue() == null) {
                    Alert alert = new Alert(AlertType.WARNING);
                    alert.setTitle("");
                    alert.setContentText("Plese select a controller!");
                    alert.showAndWait();
                } else {
                    if (controlWith.getValue().equals("Keypad")) {
                        new Viewer(dir, KEYBOARD_CONTROL, notifier);
                    } else if (controlWith.getValue().equals("Phone")) {
                        new Viewer(dir, PHONE_CONTROL, notifier);
                    } else {
                        Alert alert = new Alert(AlertType.WARNING);
                        alert.setTitle("");
                        alert.setContentText("Please check your setting!");
                        alert.showAndWait();
                    }
                }
            } else {
                Alert alert = new Alert(AlertType.WARNING);
                alert.setTitle("");
                alert.setContentText("Not a valid path!");
                alert.showAndWait();
            }
        });

        // add elements to grid
        HBox hBox = new HBox(20);
        hBox.getChildren().addAll(directoryPath, browseButton);
        layout.getChildren().addAll(hBox, controlWith, viewButton);

        this.scene = new Scene(layout, 500, 250);
        this.scene.getStylesheets().add("Style.css");
        this.window.setScene(scene);
        this.window.setResizable(false);
        window.setOnCloseRequest((event) -> {
            System.out.println("Stage is closing...");
            try {
                this.notifier.close();
            } catch (IOException ex) {
                Logger.getLogger(PhotoViewer.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        this.window.show();
        
        // set bluetooth
        this.setBluetooth();
    }

    private void setBluetooth() {
        // retrieve the local Bluetooth device object
        LocalDevice local = null;
        notifier = null;
        // setup the server to listen for connection
        try {
            local = LocalDevice.getLocalDevice();
            local.setDiscoverable(DiscoveryAgent.GIAC); // hiba helye

            UUID uuid = new UUID(80087355);
            String url = "btspp://localhost:" + uuid.toString() + ";name=RemoteBluetooth";
            notifier = (StreamConnectionNotifier) Connector.open(url);
        } catch (Exception e) {
            System.err.println("Error in connection init " + e.getMessage());
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("");
            alert.setContentText("Please check if your computer's bluetooth is active!");
            alert.showAndWait();
            this.window.close();
        }
        System.out.println("Bluetooth connection set...");
    }

    public static void main(String[] args) {
        launch(args);
    }

}
