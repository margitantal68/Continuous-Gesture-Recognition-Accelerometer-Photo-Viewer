package photoviewer;

import java.io.*;
import javax.microedition.io.StreamConnection;
import javax.microedition.io.StreamConnectionNotifier;

public class BluetoothConnection extends Thread {

    private static final int EXIT_CMD = 6;

    private ICallBack callBack;
    private byte[] buffer = new byte[1024];
    private StreamConnection connection;
    private OutputStream outputStream;
    private StreamConnectionNotifier notifier;

    public BluetoothConnection(ICallBack callBack, StreamConnectionNotifier notifier) {
        this.callBack = callBack;
        this.notifier = notifier;
    }

    @Override
    public void run() {
        this.waitForConnection();
    }

    private void waitForConnection() {
//        // retrieve the local Bluetooth device object
//        LocalDevice local = null;
//
//        notifier = null;
//        connection = null;
//
//        // setup the server to listen for connection
//        try {
//            local = LocalDevice.getLocalDevice();
//            local.setDiscoverable(DiscoveryAgent.GIAC); // hiba helye
//
//            UUID uuid = new UUID(80087355);
//            String url = "btspp://localhost:" + uuid.toString() + ";name=RemoteBluetooth";
//            notifier = (StreamConnectionNotifier) Connector.open(url);
//        } catch (Exception e) {
//            System.err.println("Error in connection init " + e.getMessage());
//            this.callBack.exception(e.getMessage());
//            return;
//        }

        try {
            System.out.println("Waiting for connection...");
            connection = notifier.acceptAndOpen();

            // prepare to receive data
            InputStream inputStream = connection.openInputStream();
            outputStream = connection.openOutputStream();

            System.out.println("Connected...");

            while (true) {
                int command = inputStream.read();
                System.out.println("Message: " + command);
                if (command == EXIT_CMD || command == -1) {
                    System.out.println("Finish process...");
                    callBack.command(EXIT_CMD);
                    break;
                }
                
                callBack.command(command);
            }
        } catch (Exception e) {
            System.err.println("Error in waitForConnection: " + e.getMessage());
            callBack.command(EXIT_CMD);
        }
    }

    public void sendMessage(String message) throws IOException {
        if(outputStream == null) return;
        this.outputStream.write(message.getBytes());
        this.outputStream.flush();
    }
    
    public void close() throws IOException{
        if(notifier == null) return;
        notifier.close();
        System.out.println("Close connection..");
    }

}
