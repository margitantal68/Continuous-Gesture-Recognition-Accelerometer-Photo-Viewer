package photoviewer;

public interface ICallBack {
    public void command(int command);
}
