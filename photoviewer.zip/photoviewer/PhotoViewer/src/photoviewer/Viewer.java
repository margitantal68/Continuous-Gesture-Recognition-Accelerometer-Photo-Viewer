package photoviewer;

import java.io.File;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javax.activation.MimetypesFileTypeMap;
import javax.microedition.io.StreamConnectionNotifier;

public class Viewer implements ICallBack {

    private static final int EXIT_CMD = 6;
    
    private Stage window;
    private Scene scene;
    private ImageView centerImageView, leftImageView, rightImageView;
    private int currentImageIndex;
    private File directory;
    private ArrayList<File> imageList;
    private int rotationAngle;
    private BluetoothConnection bluetoothConnection = null;
    private StreamConnectionNotifier notifier;

    private static final int KEYBORAD_CONTROL = 0;
    private static final double SCENE_WIDTH = 1500;
    private static final double SCENE_HEIGHT = 850;
    private static final double IMAGE_WIDTH = 1050;
    private static final double IMAGE_HEIGHT = 650;

    public Viewer(File dir, int controlType, StreamConnectionNotifier notifier) {
        this.notifier = notifier;
        this.display(dir, controlType);
        if(notifier == null) System.out.println("Notifier is null...");
    }

    private void display(File dir, int controlType) {
        directory = dir;
        currentImageIndex = 0;
        rotationAngle = 0;
        centerImageView = new ImageView();
        leftImageView = new ImageView();
        rightImageView = new ImageView();

        window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL); // block other windows
        window.setTitle("Photo Viewer");

        BorderPane layout = new BorderPane();
        layout.setPadding(new Insets(10));
        layout.setId("black-background");
        layout.setLeft(leftImageView);
        layout.setRight(rightImageView);

        // set first image
        getImagesFromDirectory();
        if (imageList.isEmpty()) {
            Label label = new Label();
            label.setText("No photos available");
            label.setId("light-grey-label");
            layout.setCenter(label);
        } else {
            setImage(imageList.get(currentImageIndex).toURI().toString());
            layout.setCenter(centerImageView);
        }

        // instruction label
        Label instructionLabel = new Label();
        instructionLabel.setId("grey-label");
        layout.setBottom(instructionLabel);

        scene = new Scene(layout, SCENE_WIDTH, SCENE_HEIGHT);
        scene.getStylesheets().add("Style.css");
        if (controlType == KEYBORAD_CONTROL && !imageList.isEmpty()) {
            setControlWithKeypad();
            instructionLabel.setText("NEXT - right arrow; PREVIOUS - left arrow; FIRST IMAGE - up arrow; LAST IMAGE - down arrow; ROTATE LEFT - L button; ROTATE RIGHT - R button");
        } else {
            instructionLabel.setText("NEXT - right gesture; PREVIOUS - left gesture; FIRST IMAGE - up gesture; LAST IMAGE - down gesture; ROTATE LEFT - left-circle gesture; ROTATE RIGHT - right-circle gesture");
            // set bluetooth and connection
            setControlWithBluetooth();
        }
        setSmallImages();
        window.setScene(scene);
        window.setResizable(true);
        window.setOnCloseRequest((event) -> {
            System.out.println("Stage is closing...");
            try {
                bluetoothConnection.sendMessage(String.valueOf(EXIT_CMD));
            } catch (Exception ex) {
                Logger.getLogger(Viewer.class.getName()).log(Level.SEVERE, null, ex);
            }
//            try {
//                bluetoothConnection.close();
//            } catch (IOException ex) {
//                Logger.getLogger(Viewer.class.getName()).log(Level.SEVERE, null, ex);
//            }
        });
        window.showAndWait();
    }

    private void setControlWithBluetooth() {
        bluetoothConnection = new BluetoothConnection(this, notifier);
        Thread thread = new Thread(bluetoothConnection);
        thread.start();
    }

    private void setControlWithKeypad() {
        scene.addEventHandler(KeyEvent.KEY_PRESSED, (event) -> {
            update(event.getCode().toString());
        });
    }

    private void update(String command) {
        System.out.println("Command: " + command);
        switch (command) {
            case "LEFT":
                if (currentImageIndex > 0) {
                    rotationAngle = 0;
                    --currentImageIndex;
                    setImage(imageList.get(currentImageIndex).toURI().toString());
                }
                break;
            case "RIGHT":
                if (currentImageIndex + 1 < imageList.size()) {
                    rotationAngle = 0;
                    ++currentImageIndex;
                    setImage(imageList.get(currentImageIndex).toURI().toString());
                }
                break;
            case "UP":
                currentImageIndex = 0;
                rotationAngle = 0;
                setImage(imageList.get(currentImageIndex).toURI().toString());
                break;
            case "DOWN":
                currentImageIndex = imageList.size() - 1;
                rotationAngle = 0;
                setImage(imageList.get(currentImageIndex).toURI().toString());
                break;
            case "R":
                rotationAngle += 90;
                rotationAngle = rotationAngle % 360;
                break;
            case "L":
                rotationAngle -= 90;
                rotationAngle = rotationAngle % 360;
                break;
        }
        centerImageView.setRotate(rotationAngle);
        if (Math.abs(rotationAngle) == 90 || Math.abs(rotationAngle) == 270) {
            centerImageView.setFitWidth(IMAGE_HEIGHT);
            centerImageView.setFitHeight(IMAGE_WIDTH);
        } else {
            centerImageView.setFitWidth(IMAGE_WIDTH);
            centerImageView.setFitHeight(IMAGE_HEIGHT);
        }
        setSmallImages();
    }

    private void setImage(String path) {
        Image image = new Image(path);
        centerImageView.setImage(image);
        centerImageView.setFitWidth(IMAGE_WIDTH);
        centerImageView.setFitHeight(IMAGE_HEIGHT);
        centerImageView.setPreserveRatio(true);
        centerImageView.setSmooth(true);
        centerImageView.setCache(true);
    }

    private void getImagesFromDirectory() {
        imageList = new ArrayList<>();
        File[] fileList = directory.listFiles();
        for (File f : fileList) {
            String mimeType = new MimetypesFileTypeMap().getContentType(f);
            if (mimeType.contains("image")) {
                imageList.add(f);
            }
            f = null;
        }
        fileList = null;
    }

    private void setSmallImages() {
        leftImageView.setImage(null);
        rightImageView.setImage(null);
        if (currentImageIndex - 1 >= 0) { // set left image
            Image image = new Image(imageList.get(currentImageIndex - 1).toURI().toASCIIString());
            leftImageView.setImage(image);
            leftImageView.setFitWidth(150);
            leftImageView.setFitHeight(100);
            leftImageView.setPreserveRatio(true);
            leftImageView.setSmooth(true);
            leftImageView.setCache(true);
        }
        if (currentImageIndex + 1 < imageList.size()) { // set right image
            Image image = new Image(imageList.get(currentImageIndex + 1).toURI().toASCIIString());
            rightImageView.setImage(image);
            rightImageView.setFitWidth(150);
            rightImageView.setFitHeight(100);
            rightImageView.setPreserveRatio(true);
            rightImageView.setSmooth(true);
            rightImageView.setCache(true);
        }
    }

    @Override
    public void command(int command) {
        if (command == EXIT_CMD) {
            Platform.runLater(
                    () -> {
                        this.window.close();
                    }
            );
            return;
        }
        String move = "";
        if (command == 4) {
            move = "R";
        }
        if (command == 5) {
            move = "L";
        }
        if (command == 3) {
            move = "RIGHT";
        }
        if (command == 2) {
            move = "LEFT";
        }
        if (command == 0) {
            move = "UP";
        }
        if (command == 1) {
            move = "DOWN";
        }
        this.update(move);
    }

}
